<?php
/**
 * All functionality of the theme is here
 */

//Theme Setup
function classicBoxTheme_setup()
{
  /**
   *  Add navigation menus into teh admin menu bar
   */
  register_nav_menus(
    [
      'primary' => esc_html__('Primary Menu', 'classic-box'),
      'footer' => esc_html__('Footer Menu', 'classic-box')
    ]
  );

  //Add featured image support
  add_theme_support('post-thumbnails');
  add_image_size('small-image', 180, 120, true);
  add_image_size('banner-image', 1170, 210, array('left', 'center'));

  //Add post format support
  add_theme_support('post-formats', array('aside', 'gallery', 'link'));

  //Add widgets support
  add_theme_support('widgets');
  add_theme_support('widgets-block-editor');

  //Get ancestor on subpages
  function get_top_ancestor_id()
  {
    global $post;
    if ($post->post_parent) {
      $ancestor = array_reverse(get_post_ancestors($post->ID));
      return $ancestor[0];
    }
    return $post->ID;
  }

  function has_children()
  {
    global $post;

    $pages = get_pages('child_of=' . $post->ID);
    return count($pages);
  }

  //Custom excerpt count legnth
  function custom_excerpt_length()
  {
    return 65;
  }
  add_filter('excerpt_length', 'custom_excerpt_length');
}
add_action('after_setup_theme', 'classicBoxTheme_setup');

/**
 * Enqueue Scripts and Styles
 */
function core_block_enqueue_script_and_style()
{
  wp_enqueue_style('main-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'core_block_enqueue_script_and_style');

/**
 * Add Widgets
 */
function classicBoxTheme_widgets()
{
  register_sidebar(
    array(
      'name' => 'Sidebar',
      'id' => 'main_sidebar',
      'before_widget' => '<div class="sidebar-area">',
      'after_widget' => '</div>',
      'before_title' => '<h2 class="widget-title">',
      'after_title' => '</h2>'
    )
  );
  register_sidebar(
    array(
      'name' => 'Footer 1',
      'id' => 'footer1',
    )
  );
  register_sidebar(
    array(
      'name' => 'Footer 2',
      'id' => 'footer2'
    )
  );
  register_sidebar(
    array(
      'name' => 'Footer 3',
      'id' => 'footer3'
    )
  );
}
add_action('widgets_init', 'classicBoxTheme_widgets');