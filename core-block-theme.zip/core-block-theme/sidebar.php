<div class="secondary-column">
    <!-- <div class="sidebar-area"> -->
    <?php dynamic_sidebar('main_sidebar'); ?>
    <!-- </div> -->
</div>